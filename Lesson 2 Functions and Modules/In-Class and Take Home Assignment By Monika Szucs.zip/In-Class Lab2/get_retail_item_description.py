"""
A script to run the get_retail_item_description() and will return the retail_item_description
:author: Monika Szucs
:date: Sept 26 2021
"""


def get_retail_item_description():
    """
    a function that will allow the user to return what the user has entered in
    First variant, parameter, return
    :return: the retail_item_description which describes in very few words what the product is
    """
    retail_item_description = input("enter retail item description:")
    return retail_item_description
    # return the retail item description that the user has entered in
